library smooth_page_indicator;

export 'src/effects/color_transition_effect.dart';
export 'src/effects/expanding_dots_effect.dart';
export 'src/effects/jumping_dot_effect.dart';
export 'src/effects/scale_effect.dart';
export 'src/effects/scrolling_dots_effect.dart';
export 'src/effects/slide_effect.dart';
export 'src/effects/swap_effect.dart';
export 'src/effects/worm_effect.dart';
export 'src/effects/customizable_effect.dart';
export 'src/smooth_page_indicator.dart';
